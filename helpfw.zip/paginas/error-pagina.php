<br />
<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="info-box">
        <span class="info-box-icon bg-red"><i class="fa fa-times"></i></span>

        <div class="info-box-content">
            <span class="info-box-text"><i class="fa fa-warning text-yellow"></i> Oops!</span>
            <span class="info-box-number">Página não encontrada...</span>
        </div>
        <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
</div>