<?php

$endereco = $_GET['endereco'];
?>

